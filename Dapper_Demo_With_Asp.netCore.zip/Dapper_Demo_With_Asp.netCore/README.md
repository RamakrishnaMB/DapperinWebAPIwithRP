# Dapper_Demo_With_Asp.netCore
This is the basic demo for Dapper+StoreProcedure+Asp.net Core Web API 3.0+.net standard 2.0

For more detials please refer this blog post

https://chandradev819.wordpress.com/2019/12/12/creating-web-api-core-3-0-layer-using-dapper-and-net-standard-2-0/


